Ms.Williams
===========

WHAT'S INSIDE
  MsWilliamsShadow-Regular.ttf   Ms.Williams: hand-drawn pink letters with a black outline and
                                 3D drop shadow built in. Shows up as "Ms.Williams Shadow" in font menus.
  web/                           The same font as a .woff2 file for websites.

INSTALL
  Mac:       Double-click the .ttf file, then click "Install Font".
  Windows:   Right-click the .ttf file and choose "Install".
  Procreate: Actions (wrench) > Add > Add Text, tap the text, then Edit Style > Import Font
             and choose the .ttf file.
  Remove any older versions of the font before installing a new one.

GOOD TO KNOW
  The pink and black are part of the font, so changing the text colour won't change them.
  Shows in full colour in Illustrator, Photoshop, InDesign, Mac apps (Pages, Keynote, TextEdit),
  Windows 10/11 apps and web browsers. Apps that can't show colour fonts, such as Figma,
  show the letters without the outline and shadow.

TYPE THE HAND-DRAWN SHAPES
  devil          type  {
  HW logomark    type  }
  heart          type  <3     (turns into the heart as you type)
  { and } are on every keyboard; on phones they're on the symbols page (#+=).
  In Microsoft Word, the <3 heart needs Font > Advanced > Ligatures > Standard Only.

LICENSE
  Free for personal, non-commercial use only. See LICENSE.txt.
